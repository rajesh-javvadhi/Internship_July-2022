# Write a function

def is_leap(year):
    leap = " "
    if 1900<=year<=10**5:
        if year%4==0:
            leap="True"
        elif year%4!=0:
            leap="False"
        if year%100==0:
            leap="False"
            if year%400==0:
                leap="True"
    return leap