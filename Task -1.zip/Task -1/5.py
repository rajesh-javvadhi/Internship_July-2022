## Loops

n = int(input())
for i in range(n):
    if i<=n<=20:
        print(i**2)