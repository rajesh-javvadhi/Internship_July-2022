# Print Function

n = int(input())
a =''
for i in range(1,n+1):
    if i<=n<=150:
        a=a+str(i)
print(a)